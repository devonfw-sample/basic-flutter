'use strict';


/**
 *
 * id Long 
 * no response value expected for this operation
 **/
exports.employeemanagementV1EmployeeIdDELETE = function(id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

