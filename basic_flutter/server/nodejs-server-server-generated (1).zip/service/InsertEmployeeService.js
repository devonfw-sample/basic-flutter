'use strict';


/**
 *
 * body EmployeeInsertRequestDtoSchema  (optional)
 * returns EmployeeInsertResponseDtoSchema
 **/
exports.employeemanagementV1EmployeePOST = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "surname" : "surname",
  "modificationCounter" : 0,
  "name" : "name",
  "id" : 6,
  "email" : "email"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

